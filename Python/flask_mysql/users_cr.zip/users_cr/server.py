from flask import Flask, render_template,session,redirect,request
from users import User
app = Flask(__name__)
app.secret_key = 'hi'

@app.route('/')
def index():
    return redirect('/user')

@app.route('/user')
def all_users():
    users = User.get_all_users()
    print(users)
    return render_template('read_all.html',all_users= users)

@app.route('/user/new')
def create_user_page():
    return render_template('create.html')

@app.route('/user/create',methods=['POST'])
def create():
    print(request.form)
    User.create_user(request.form)
    return redirect('/user')

if __name__=="__main__":   
    app.run(debug=True)    