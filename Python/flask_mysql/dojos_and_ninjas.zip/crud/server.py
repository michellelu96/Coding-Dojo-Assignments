from dojos_and_ninjas import app
from dojos_and_ninjas.controllers.dojos import Dojo
from dojos_and_ninjas.controllers.ninjas import Ninja


           


if __name__=="__main__":   
    app.run(debug=True)    