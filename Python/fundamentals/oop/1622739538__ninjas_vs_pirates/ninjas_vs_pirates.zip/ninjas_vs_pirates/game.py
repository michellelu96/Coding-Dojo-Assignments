from classes.ninja import Ninja
from classes.ninja import NinjaRed
from classes.ninja import NinjaBlue
from classes.ninja import NinjaBoss
from classes.pirate import Pirate

boss = NinjaBoss("Sensei Jim")
blue = NinjaBlue("Michealanglo")
red = NinjaRed('Max')
normal = Ninja('Christian')


jack_sparrow = Pirate("Captain Jack Sparrow")

boss.attack(jack_sparrow)
blue.attack(jack_sparrow)
red.attack(jack_sparrow)
normal.attack(jack_sparrow)
jack_sparrow.show_stats()
jack_sparrow.attack(normal)
boss.attack(jack_sparrow)
blue.attack(jack_sparrow)
red.attack(jack_sparrow)
jack_sparrow.show_stats()
jack_sparrow.attack(red)
boss.attack(jack_sparrow)
blue.attack(jack_sparrow)
jack_sparrow.attack(blue)
jack_sparrow.show_stats()
boss.attack(jack_sparrow)

