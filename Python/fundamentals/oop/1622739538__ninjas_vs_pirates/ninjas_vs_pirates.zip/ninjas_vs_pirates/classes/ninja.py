class Ninja:


    def __init__( self , name):
        self.name = name
        self.strength = 30
        self.speed = 5
        self.health = 100
    
    def show_stats( self ):
        print(f"Name: {self.name}\nStrength: {self.strength}\nSpeed: {self.speed}\nHealth: {self.health}\n")

    def attack( self , pirate ):
        pirate.health -= self.strength
        print(f"{self.name} attacked {pirate.name} for {self.strength} health")
        if (pirate.health >  0):
            print("aaaaaarggggg i've been hit")
        elif(pirate.health <= 0):
            print("aaaaaarggggg I've been defeated, but I will be back!")
        return self


class NinjaRed(Ninja):
    def __init__(self, name):
        super().__init__(name)
        self.strength = 20
        self.speed = 15
        self.health = 100

class NinjaBoss(Ninja):
    def __init__(self, name):
        super().__init__(name)
        self.strength = 100
        self.speed = 10
        self.health = 120

class NinjaBlue(Ninja):
    def __init__(self, name):
        super().__init__(name)
        self.strength = 40
        self.speed = 5
        self.health=100


