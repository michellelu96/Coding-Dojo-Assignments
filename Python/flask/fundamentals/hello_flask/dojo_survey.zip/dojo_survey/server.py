import random
from flask import Flask, render_template,session,redirect,request
app = Flask(__name__)
app.secret_key = 'hi'

@app.route('/')
def survey():
    return render_template('/index.html')

@app.route('/results')
def results():
    print(request.form)
    return render_template('result.html')

@app.route('/results',methods=['POST'])
def info():
    print(request.form)
    session['name'] = request.form['name']
    session['location']= request.form['location']
    session['language'] = request.form['language']
    session['comments'] = request.form['comments']
    return render_template('result.html',name=session['name'],location=session['location'],language=session['language'],comment=session['comments'])

@app.route('/reset',methods=['POST'])
def reset():
    session.clear()
    return redirect('/')

if __name__=="__main__":   
    app.run(debug=True)    